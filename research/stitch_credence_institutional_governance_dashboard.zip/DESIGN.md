---
name: Institutional Governance System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474e'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f87'
  primary: '#022448'
  on-primary: '#ffffff'
  primary-container: '#1e3a5f'
  on-primary-container: '#8aa4cf'
  inverse-primary: '#adc8f5'
  secondary: '#7b5900'
  on-secondary: '#ffffff'
  secondary-container: '#fcca66'
  on-secondary-container: '#755400'
  tertiary: '#242421'
  on-tertiary: '#ffffff'
  tertiary-container: '#393936'
  on-tertiary-container: '#a4a39e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#adc8f5'
  on-primary-fixed: '#001c3b'
  on-primary-fixed-variant: '#2d486d'
  secondary-fixed: '#ffdea4'
  secondary-fixed-dim: '#f0bf5c'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4200'
  tertiary-fixed: '#e5e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1c1c19'
  on-tertiary-fixed-variant: '#474743'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

This design system is built for institutional governance, prioritizing clarity, trust, and rhythmic space. The aesthetic leans into **Corporate Minimalism**, drawing inspiration from high-end SaaS platforms like Stripe and Microsoft Admin. It rejects the frantic energy of consumer-facing tech in favor of a "quiet luxury" approach for enterprise software.

The brand personality is authoritative yet approachable. It uses a "White Label" philosophy where the interface recedes to let the data and decision-making take center stage. The emotional response should be one of stability and competence—achieved through generous whitespace, high-quality typography, and a "Soft Enterprise" feel that avoids the coldness of traditional legacy systems.

## Colors

The palette is anchored in a sophisticated, low-strain warmth. 

- **Primary (#1E3A5F):** A Deep Navy Blue used for primary actions, navigation sidebars, and high-level headings. It represents gravity and institutional trust.
- **Accent (#C79A3B):** A Soft Gold used sparingly for "hero" moments, such as successful verification badges, active states in navigation, or subtle progress indicators.
- **Base (#FAF7F2):** A Warm Cream background that reduces the harshness of pure white (#FFFFFF), which is reserved exclusively for elevated cards and input fields.
- **Neutrals:** A scale of slate grays is used for secondary text and borders to maintain a soft contrast ratio that meets accessibility standards without appearing "heavy."

## Typography

The design system utilizes **Inter** exclusively to ensure a systematic, utilitarian feel that remains highly legible across high-density data tables and complex forms. 

Headlines use tighter letter spacing and heavier weights to anchor the page. Body text maintains standard tracking for maximum readability. Labels and metadata utilize a slightly increased letter-spacing and semi-bold weights to differentiate them from interactive body text. For mobile, headline sizes are scaled down to prevent awkward word-breaks in narrow viewports.

## Layout & Spacing

The layout philosophy follows a **Fluid Grid** model with strict maximum widths for content readability. 

- **Desktop:** A 12-column grid with 24px gutters. Page margins are set to 40px or 64px to create a "canvas" feel on the Cream background.
- **Tablet:** An 8-column grid with 24px gutters and 24px margins.
- **Mobile:** A 4-column grid with 16px gutters and 16px margins.

Spacing follows a geometric 4pt scale. Component internal padding should favor the larger end of the scale (e.g., 24px or 32px) to maintain the "Large Spacing" aesthetic requested. Blocks of content should be separated by `2xl` (64px) spacing to avoid visual clutter in complex governance workflows.

## Elevation & Depth

This system uses **Tonal Layering** combined with **Ambient Shadows** to create a sense of organized hierarchy.

- **Level 0 (Background):** The Warm Cream (#FAF7F2) surface.
- **Level 1 (Cards/Content):** Pure White (#FFFFFF) surfaces with a very soft, diffused shadow (Hex: #1E3A5F at 4% opacity, 12px blur, 4px Y-offset). This makes cards feel "tucked in" rather than floating.
- **Level 2 (Dropdowns/Modals):** Pure White surfaces with a more pronounced shadow (Hex: #1E3A5F at 8% opacity, 24px blur, 12px Y-offset) to indicate immediate priority.

Borders should be used minimally, primarily as a 1px solid line in a light neutral (e.g., Slate 100) to define table headers or input field boundaries.

## Shapes

The shape language is consistently **Rounded**, avoiding the harshness of 0px corners while staying professional. 

- **Standard Elements:** Buttons, inputs, and small cards use a 0.5rem (8px) radius.
- **Large Containers:** Main content areas and large dashboard cards use a 1rem (16px) radius.
- **Status Indicators:** Pills and tags use a fully rounded (999px) radius to distinguish them from interactive buttons.

This consistent rounding softens the "institutional" nature of the product, making the software feel modern and user-friendly.

## Components

- **Buttons:** Primary buttons are Solid Navy (#1E3A5F) with White text. Secondary buttons are Ghost-style with a Navy border and Navy text. Action buttons have a 48px height for a premium, tactile feel.
- **Input Fields:** Pure White background with a subtle 1px Slate border. On focus, the border transitions to Soft Gold (#C79A3B) with a faint outer glow.
- **Cards:** The workhorse of the UI. Always White, always rounded (16px), and always featuring the ambient shadow defined in Elevation.
- **Lists & Tables:** Rows should have generous vertical padding (16px-20px). Use subtle horizontal dividers rather than vertical grid lines to maintain a clean, open look.
- **Chips/Badges:** For blockchain-verified status, use a Soft Gold background at 10% opacity with Solid Gold text and a Lucide "ShieldCheck" icon.
- **Icons:** Use the **Lucide** icon set. Icons should be set to a 20px size within a 24px frame for standard UI, using a "Regular" (2px) stroke weight to match the Inter typeface.
- **Governance Steppers:** A custom vertical progress component using the Navy/Gold palette to show the "Chain of Custody" or approval flow of institutional documents.