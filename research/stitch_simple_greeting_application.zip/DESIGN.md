---
name: Academic Authority
colors:
  surface: '#f8f9ff'
  surface-dim: '#d1dbec'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dfe9fa'
  surface-container-highest: '#d9e3f4'
  on-surface: '#121c28'
  on-surface-variant: '#43474e'
  inverse-surface: '#27313e'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f87'
  primary: '#022448'
  on-primary: '#ffffff'
  primary-container: '#1e3a5f'
  on-primary-container: '#8aa4cf'
  inverse-primary: '#adc8f5'
  secondary: '#7b5900'
  on-secondary: '#ffffff'
  secondary-container: '#fcca66'
  on-secondary-container: '#755400'
  tertiary: '#242421'
  on-tertiary: '#ffffff'
  tertiary-container: '#393936'
  on-tertiary-container: '#a4a39e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#adc8f5'
  on-primary-fixed: '#001c3b'
  on-primary-fixed-variant: '#2d486d'
  secondary-fixed: '#ffdea4'
  secondary-fixed-dim: '#f0bf5c'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4200'
  tertiary-fixed: '#e5e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1c1c19'
  on-tertiary-fixed-variant: '#474743'
  background: '#f8f9ff'
  on-background: '#121c28'
  surface-variant: '#d9e3f4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-lg: 48px
  stack-md: 24px
  stack-sm: 12px
---

## Brand & Style

This design system is built for a high-stakes academic environment where trust, permanence, and prestige are paramount. The aesthetic moves away from the volatile tropes of web3 and instead adopts a "Digital Institution" persona—combining the weight of traditional academia with the efficiency of enterprise SaaS.

The visual style is characterized by **Refined Minimalism**. It utilizes heavy whitespace to convey a sense of calm and clarity, essential for verifying sensitive credentials. The UI is structured, balanced, and professional, prioritizing high-legibility and a sense of institutional security. The emotional goal is to evoke the feeling of holding a physical, high-quality parchment degree within a modern, frictionless digital interface.

## Colors

The palette is anchored by **Deep Navy Blue**, representing stability and authority. This is contrasted by **Soft Gold**, used sparingly for highlights and significant achievements (e.g., verified badges, honor status) to mimic traditional academic seals. 

The background environment uses a **Warm Cream** to soften the digital experience, distinguishing it from the sterile whites of common SaaS platforms. Success states use a grounded forest green to signify validation without feeling overly clinical. Gradients are strictly forbidden; color application must be solid and purposeful to maintain a "printed" quality.

## Typography

The typography system relies exclusively on **Inter** to ensure maximum cross-platform clarity and a systematic, utilitarian feel. 

Large headings use tighter letter-spacing and heavier weights to create an "editorial" impact, while body text maintains generous line heights for long-form credential descriptions. Information density is managed through a strict hierarchy: use `label-sm` in uppercase for metadata titles and `body-md` for the actual data. This clear distinction ensures that complex blockchain data remains readable and non-intimidating.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain the "document" feel, centered within the viewport. A 12-column grid is used with generous 24px gutters to ensure elements never feel crowded.

On mobile, the layout transitions to a single-column fluid flow with 16px side margins. Horizontal "stacking" is avoided in favor of verticality to keep the interface easy to scan. Vertical rhythm is governed by an 8px base unit; major sections are separated by `stack-lg` (48px) to provide significant breathing room, reinforcing the premium, unhurried nature of the brand.

## Elevation & Depth

Elevation is achieved through **Ambient Shadows** rather than lines. Surfaces should feel like they are gently resting on the Warm Cream background. 

Shadows use the Deep Navy Blue color in their tint at extremely low opacity (4-8%) to maintain a natural, cohesive look. We avoid borders for card containers, using the contrast between the white card and the cream background to define edges. This creates a "layered paper" effect. 

- **Level 1 (Default Card):** 0px 4px 20px rgba(30, 58, 95, 0.04)
- **Level 2 (Hover/Active):** 0px 10px 30px rgba(30, 58, 95, 0.08)
- **Level 3 (Modals):** 0px 20px 50px rgba(30, 58, 95, 0.12)

## Shapes

The design system uses a consistent **14px corner radius** (`rounded-lg`) for primary cards and containers. This specific radius is soft enough to feel modern and welcoming but structured enough to feel professional. 

Buttons and smaller interactive elements (inputs, tags) should scale down to 8px-10px to maintain visual harmony. Circular shapes are reserved exclusively for avatars and status indicators to contrast against the predominantly rectangular architecture.

## Components

### Buttons
- **Primary:** Deep Navy Blue background, white text. No border. Solid, heavy presence.
- **Secondary:** Transparent background, Deep Navy Blue border (1px) and text.
- **Tertiary/Ghost:** Soft Gold text, no background. Used for low-priority actions or "View Details."

### Cards
Cards are the primary container for certificates. They must have a white background, 14px border radius, and Level 1 elevation. No borders.

### Input Fields
Inputs should have a subtle #F3F4F6 background and no border in their default state. On focus, they transition to a 1px Deep Navy Blue border. Labels sit above the field in `label-sm` (uppercase).

### Chips & Badges
Used for status (e.g., "Verified," "Pending"). They use a 4px radius (sharper than cards) and high-contrast combinations:
- **Verified:** Soft Gold background (10% opacity) with Deep Navy Blue text, or Solid Green for "Success."

### Verification Timeline
A unique component for this system—a vertical line with nodes representing blockchain verification steps. Use Soft Gold for active/completed steps and Modern Gray (#9CA3AF) for upcoming steps.